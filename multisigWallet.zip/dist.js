const folderZip = require('folder-zip');
const zip = new folderZip();
const options = {
	excludeParentFolder: true
};

zip.zipFolder('./', options, function () {
	zip.writeToFile('../multisigWalletGnosis.zip');
});
