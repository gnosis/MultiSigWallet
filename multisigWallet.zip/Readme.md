# Multisignature Wallet UI
Web UI for [MultiSigWallet](https://github.com/ConsenSys/MultiSigWallet)

# Requirements
* Node v5+
* [Grunt-cli](http://gruntjs.com/getting-started#installing-the-cli)
* [bower](https://bower.io/#install-bower)

# Develop
```
npm install -g bower
npm install -g grunt-cli
npm install
bower install
grunt
```
